import React from 'react'

export const Paymentsuccess = () => {
  return (
    <div>
        <a href='https://buy.stripe.com/test_28oaHM5gVeGN2EUdQQ' />
    </div>
  )
}
